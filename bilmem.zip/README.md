# 🎁 AI-Hediye - Yapay Zeka ile Hediye Önerisi

Yapay zeka destekli akıllı hediye öneri platformu. Kullanıcıların birkaç basit soruya cevap vermesiyle kişiselleştirilmiş hediye önerileri sunar.

## 🚀 Özellikler

- ✨ Google Gemini AI ile akıllı hediye önerileri
- 🎯 5 adımlı kullanıcı dostu wizard
- 🖼️ Gerçek ürün görselleri (Google Image Search)
- 💰 Dinamik fiyat aralıkları
- 📱 Tam responsive tasarım
- 🎨 Modern UI/UX (Tailwind CSS 4)

## 📋 Gereksinimler

- Node.js 18+ veya 20+
- npm, yarn, pnpm veya bun

## ⚙️ Kurulum

1. **Projeyi klonlayın:**
```bash
git clone <repo-url>
cd ai-hediye
```

2. **Bağımlılıkları yükleyin:**
```bash
npm install
# veya
yarn install
# veya
pnpm install
```

3. **Environment variables ayarlayın:**

`.env.example` dosyasını `.env.local` olarak kopyalayın:
```bash
cp .env.example .env.local
```

Ardından `.env.local` dosyasını düzenleyip gerekli API key'leri ekleyin:

```bash
# ZORUNLU
GOOGLE_API_KEY=your_google_api_key_here

# OPSİYONEL (fiyat karşılaştırma için)
SERPAPI_KEY=your_serpapi_key_here
# VEYA
GOOGLE_CSE_API_KEY=your_google_cse_api_key_here
GOOGLE_CSE_CX=your_custom_search_engine_id_here
```

**API Key'leri nereden alınır?**
- **Google Gemini API:** [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
- **SerpAPI (opsiyonel):** [https://serpapi.com/](https://serpapi.com/)
- **Google CSE (opsiyonel):** [https://developers.google.com/custom-search](https://developers.google.com/custom-search)

4. **Development server'ı başlatın:**
```bash
npm run dev
```

Tarayıcınızda [http://localhost:3000](http://localhost:3000) adresini açın.

## 🏗️ Teknoloji Stack

- **Framework:** Next.js 16.1.1 (App Router)
- **UI:** React 19.2.3
- **Styling:** Tailwind CSS 4
- **Language:** TypeScript 5
- **AI:** Google Gemini 2.0 Flash
- **Image Search:** g-i-s (Google Image Search)

## 📁 Proje Yapısı

```
src/
├── app/
│   ├── api/recommend/     # AI öneri API endpoint
│   ├── wizard/            # Wizard flow sayfası
│   ├── results/           # Sonuçlar sayfası
│   └── page.tsx           # Ana sayfa
├── components/
│   ├── ui/                # Genel UI bileşenleri
│   ├── layout/            # Header, Footer
│   └── home/              # Ana sayfa bileşenleri
├── lib/
│   ├── giftEngine.ts      # Öneri motoru
│   ├── constants.ts       # Sabitler
│   ├── priceService.ts    # Fiyat servisi
│   └── analytics.ts       # Analytics
├── context/
│   └── WizardContext.tsx  # State management
└── types/
    └── index.ts           # TypeScript tipleri
```

## 🧪 Test

```bash
npm run lint
```

## 🚢 Production Build

```bash
npm run build
npm run start
```

## 📝 License

MIT

## 🤝 Katkıda Bulunma

Pull request'ler memnuniyetle karşılanır. Büyük değişiklikler için lütfen önce bir issue açın.
