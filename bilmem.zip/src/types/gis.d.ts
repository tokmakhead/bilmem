declare module 'g-i-s';
